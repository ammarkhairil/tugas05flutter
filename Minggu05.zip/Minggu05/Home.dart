import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'Http.Helper.dart';
import 'detail.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  HttpHelper? helper;
  List? movies;
  final String iconBase = "https://image.tmdb.org/t/p/w92";
  final String defaultImage =
      "https://images.freeimages.com/images/large-previews/5eb/movie-clapboard-1184339.jpg";

  @override
  void initState() {
    helper = HttpHelper();
    initialize();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    NetworkImage image;
    return Scaffold(
        appBar: AppBar(
          title: const Text("Now Playing"),
        ),
        body: ListView.builder(
          itemCount: (movies?.length == null) ? 0 : movies?.length,
          itemBuilder: (BuildContext context, int position) {
            if (movies![position].posterPath != null) {
              image = NetworkImage(iconBase + movies![position].posterPath);
            } else {
              image = NetworkImage(defaultImage);
            }
            return Card(
              color: Colors.white,
              elevation: 2.0,
              child: ListTile(
                onTap: () {
                  MaterialPageRoute route = MaterialPageRoute(
                      builder: (_) => DetailScreen(movies![position]));
                  Navigator.push(context, route);
                },
                leading: CircleAvatar(
                  backgroundImage: image,
                ),
                title: Text(movies![position].title),
                subtitle: Text(
                    "${"Released: " + movies![position].releaseDate} - Vote: ${movies![position].voteAverage}"),
              ),
            );
          },
        ));
  }

  Future initialize() async {
    movies = await helper?.getMovie();
    setState(() {
      movies = movies;
    });
  }
}

Future fetchData() async {
  final respon = await http.get(Uri.parse('http'));
}
